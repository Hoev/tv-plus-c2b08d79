
import React, { useState, useEffect, useRef } from 'react';
import ReactDOM from 'react-dom/client';

declare const shaka: any;

declare global {
  interface Window {
    YT: any;
    onYouTubeIframeAPIReady: any;
  }
}

const ProPlayer = ({ stream, onClose }: any) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const ytContainerRef = useRef<HTMLDivElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const [player, setPlayer] = useState<any>(null);
  const [ytPlayer, setYtPlayer] = useState<any>(null);
  
  // UI State
  const [showHUD, setShowHUD] = useState(true);
  const [isBuffering, setIsBuffering] = useState(true);
  const [aspectRatio, setAspectRatio] = useState<'contain' | 'cover'>('contain');
  const [isYoutube, setIsYoutube] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [menu, setMenu] = useState<{ open: boolean; type: 'audio' | 'subtitle' | 'quality' }>({ open: false, type: 'quality' });
  const [isFullScreen, setIsFullScreen] = useState(false);

  // Stream Data State
  const [tracks, setTracks] = useState<{
    audio: any[];
    quality: any[];
    currentAudio: string;
    currentQuality: string; // 'auto' or height value
  }>({ audio: [], quality: [], currentAudio: '', currentQuality: 'auto' });

  // Playback State
  const [controls, setControls] = useState({
    playing: true,
    progress: 0,
    currentTime: "00:00",
    totalTime: "00:00",
  });

  const timerRef = useRef<any>(null);

  const getYTId = (url: string) => {
    if (!url) return null;
    const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=|live\/)([^#&?]*).*/;
    const match = url.match(regExp);
    return (match && match[2].length === 11) ? match[2] : null;
  };

  // --- Removed Auto-Landscape on Mount ---
  // The user requested to NOT force horizontal mode immediately.
  // Orientation lock will only happen on Fullscreen toggle.

  useEffect(() => {
    setIsBuffering(true);
    setError(null);
    const videoId = getYTId(stream.url);

    if (videoId) {
      setIsYoutube(true);
      setTimeout(() => initYoutube(videoId), 100);
    } else {
      setIsYoutube(false);
      setTimeout(() => initShaka(), 100);
    }

    return () => {
      // Release orientation lock if player closes while in fullscreen
      if (document.fullscreenElement) {
        document.exitFullscreen().catch(() => {});
      }
      if (screen.orientation && (screen.orientation as any).unlock) {
        try { (screen.orientation as any).unlock(); } catch(e) {}
      }
      
      if (player) {
        player.destroy();
        setPlayer(null);
      }
    };
  }, [stream.url]);

  // --- YouTube Initialization ---
  const initYoutube = (videoId: string) => {
    const startPlayer = () => {
      if (!window.YT || !window.YT.Player || !ytContainerRef.current) return;
      try {
        new window.YT.Player(ytContainerRef.current, {
          videoId: videoId,
          height: '100%',
          width: '100%',
          playerVars: { autoplay: 1, controls: 0, modestbranding: 1, rel: 0, iv_load_policy: 3, fs: 0, playsinline: 1, origin: window.location.origin },
          events: {
            onReady: (event: any) => {
              setYtPlayer(event.target);
              event.target.playVideo();
              setIsBuffering(false);
              startYTTracking(event.target);
            },
            onStateChange: (event: any) => {
              setIsBuffering(event.data === window.YT.PlayerState.BUFFERING);
              setControls(c => ({...c, playing: event.data === window.YT.PlayerState.PLAYING}));
            },
            onError: (e: any) => setError("YouTube Error Code: " + e.data)
          }
        });
      } catch (e) { console.error(e); }
    };

    if (!window.YT) {
      const tag = document.createElement('script');
      tag.src = "https://www.youtube.com/iframe_api";
      document.body.appendChild(tag);
      window.onYouTubeIframeAPIReady = startPlayer;
    } else {
      startPlayer();
    }
  };

  const startYTTracking = (p: any) => {
    const track = () => {
      if (!p || typeof p.getCurrentTime !== 'function') return;
      try {
        const cur = p.getCurrentTime();
        const dur = p.getDuration();
        setControls(c => ({
          ...c,
          progress: (cur / dur) * 100 || 0,
          currentTime: formatTime(cur),
          totalTime: formatTime(dur)
        }));
      } catch (e) {}
      requestAnimationFrame(track);
    };
    track();
  };

  // --- Shaka Player Initialization (The Core Logic) ---
  const initShaka = async () => {
    if (!videoRef.current) return;
    shaka.polyfill.installAll();
    
    if (!shaka.Player.isBrowserSupported()) {
      setError("Browser not supported");
      return;
    }

    const shakaPlayer = new shaka.Player(videoRef.current);
    
    // Config
    const config: any = { streaming: { bufferingGoal: 10, lowLatencyMode: true } };
    if (stream.drm && stream.drm.clearKeys) config.drm = { clearKeys: stream.drm.clearKeys };
    shakaPlayer.configure(config);

    // Networking Interceptor for Headers (User-Agent, Referer, etc)
    shakaPlayer.getNetworkingEngine().registerRequestFilter((type: any, request: any) => {
        if (stream.headers) {
            Object.keys(stream.headers).forEach(key => {
                request.headers[key] = stream.headers[key];
            });
        }
    });

    // Event Listeners for Tracks/Quality
    shakaPlayer.addEventListener('trackschanged', () => updateShakaTracks(shakaPlayer));
    shakaPlayer.addEventListener('variantchanged', () => updateShakaTracks(shakaPlayer));
    shakaPlayer.addEventListener('buffering', (e: any) => setIsBuffering(e.buffering));
    shakaPlayer.addEventListener('error', (e: any) => { console.error(e); setError(`Error: ${e.detail.code}`); });

    setPlayer(shakaPlayer);

    try {
      await shakaPlayer.load(stream.url);
      videoRef.current.play();
      setIsBuffering(false);
    } catch (e: any) {
      console.error(e);
      setError(`Load Error: ${e.code}`);
      setIsBuffering(false);
    }
  };

  // Function to extract Tracks from Shaka
  const updateShakaTracks = (p: any) => {
    const variantTracks = p.getVariantTracks();
    
    // Process Quality (Video)
    // Filter out audio-only tracks and duplicate heights
    const qualities = variantTracks
      .filter((t: any) => t.type === 'variant' && t.height)
      .reduce((acc: any[], current: any) => {
        if (!acc.find(item => item.height === current.height)) {
          acc.push(current);
        }
        return acc;
      }, [])
      .sort((a: any, b: any) => b.height - a.height); // Sort High to Low

    // Process Audio
    const audioLangs = p.getAudioLanguages();

    setTracks(prev => ({
      ...prev,
      quality: qualities,
      audio: audioLangs,
      currentAudio: p.getAudioLanguages()[0] || '', // Default first
      // If ABR is enabled, we are in Auto
      currentQuality: p.getConfiguration().abr.enabled ? 'auto' : prev.currentQuality
    }));
  };

  // --- Interaction Logic ---

  const changeQuality = (height: number | 'auto') => {
    if (!player) return;
    
    if (height === 'auto') {
      player.configure({ abr: { enabled: true } });
      setTracks(t => ({ ...t, currentQuality: 'auto' }));
    } else {
      player.configure({ abr: { enabled: false } }); // Turn off Auto
      const tracks = player.getVariantTracks().filter((t: any) => t.height === height);
      if (tracks.length > 0) {
        player.selectVariantTrack(tracks[0], true); // Safe buffer clear
      }
      setTracks(t => ({ ...t, currentQuality: height.toString() }));
    }
    setMenu({ ...menu, open: false });
  };

  const changeAudio = (lang: string) => {
    if (!player) return;
    player.selectAudioLanguage(lang);
    setTracks(t => ({ ...t, currentAudio: lang }));
    setMenu({ ...menu, open: false });
  };

  const toggleFullScreen = async () => {
    try {
      if (!document.fullscreenElement) {
        if (containerRef.current) {
          await containerRef.current.requestFullscreen();
        }
        // Lock orientation ONLY when entering fullscreen
        if (screen.orientation && (screen.orientation as any).lock) {
          await (screen.orientation as any).lock('landscape').catch(() => {});
        }
        setIsFullScreen(true);
      } else {
        await document.exitFullscreen();
        // Unlock orientation when exiting fullscreen
        if (screen.orientation && (screen.orientation as any).unlock) {
          try { (screen.orientation as any).unlock(); } catch(e) {}
        }
        setIsFullScreen(false);
      }
    } catch (err) {
      console.error("Fullscreen toggle failed:", err);
    }
  };

  const togglePlay = (e: any) => {
    e.stopPropagation();
    if (isYoutube && ytPlayer) {
      controls.playing ? ytPlayer.pauseVideo() : ytPlayer.playVideo();
    } else if (videoRef.current) {
      videoRef.current.paused ? videoRef.current.play() : videoRef.current.pause();
    }
    setControls(c => ({ ...c, playing: !c.playing }));
    resetHUDTimer();
  };

  const resetHUDTimer = () => {
    if (timerRef.current) clearTimeout(timerRef.current);
    timerRef.current = setTimeout(() => { if(!menu.open) setShowHUD(false); }, 5000);
  };

  const formatTime = (s: number) => {
    if (isNaN(s) || s === Infinity) return "LIVE";
    const m = Math.floor(s / 60);
    const sec = Math.floor(s % 60);
    return `${String(m).padStart(2, '0')}:${String(sec).padStart(2, '0')}`;
  };

  return (
    <div 
      ref={containerRef} 
      className="fixed inset-0 z-[9000] bg-black flex items-center justify-center overflow-hidden select-none font-sans"
      onClick={() => { setShowHUD(!showHUD); if(!showHUD) resetHUDTimer(); }}
      onMouseMove={() => { setShowHUD(true); resetHUDTimer(); }}
    >
      {error && (
        <div className="absolute inset-0 z-50 flex flex-col items-center justify-center bg-black/95 text-white p-4 text-center">
           <svg className="w-16 h-16 text-red-600 mb-4" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg>
           <p className="text-xl font-bold mb-6">{error}</p>
           <button onClick={onClose} className="px-8 py-3 bg-white/10 rounded-full hover:bg-white/20 border border-white/10">إغلاق</button>
        </div>
      )}

      {/* Video Layer */}
      {isYoutube ? (
        <div className={`w-full h-full pointer-events-none transition-transform duration-300 ${aspectRatio === 'cover' ? 'scale-[1.35]' : 'scale-100'}`}>
          <div ref={ytContainerRef} className="w-full h-full" />
          <div className="absolute inset-0 z-10" />
        </div>
      ) : (
        <video 
          ref={videoRef} 
          autoPlay 
          playsInline
          className={`w-full h-full transition-all duration-300 ${aspectRatio === 'contain' ? 'object-contain' : 'object-cover'}`}
          onTimeUpdate={() => {
            if (!videoRef.current) return;
            const v = videoRef.current;
            setControls(c => ({ 
              ...c, 
              progress: (v.currentTime/v.duration)*100 || 0, 
              currentTime: formatTime(v.currentTime), 
              totalTime: formatTime(v.duration) 
            }));
          }}
        />
      )}

      {isBuffering && !error && (
        <div className="absolute inset-0 flex items-center justify-center bg-black/50 z-20 pointer-events-none">
          <div className="w-16 h-16 border-4 border-gold/30 border-t-gold rounded-full animate-spin"></div>
        </div>
      )}

      {/* HUD Layer */}
      <div className={`absolute inset-0 flex flex-col justify-between p-4 md:p-8 z-30 transition-opacity duration-300 bg-gradient-to-b from-black/80 via-transparent to-black/90 ${showHUD ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
        
        {/* Top Bar */}
        <div className="flex justify-between items-start">
           <div className="flex items-center gap-4">
             <button onClick={(e) => { e.stopPropagation(); onClose(); }} className="focusable p-3 bg-white/10 rounded-full hover:bg-red-600 transition-colors backdrop-blur-md">
                <svg className="w-6 h-6 text-white" fill="none" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24"><path d="M15 19l-7-7 7-7"/></svg>
             </button>
             <div className="mt-1">
                <h2 className="text-lg md:text-2xl font-black text-white drop-shadow-md leading-none">{stream.title}</h2>
                <div className="flex items-center gap-2 mt-1">
                   <span className="w-2 h-2 bg-red-600 rounded-full animate-pulse shadow-[0_0_8px_red]"></span>
                   <span className="text-[10px] font-bold text-white/60 tracking-widest uppercase">
                     {isYoutube ? 'YOUTUBE LIVE' : (tracks.currentQuality === 'auto' ? 'AUTO HD' : `${tracks.currentQuality}p`)}
                   </span>
                </div>
             </div>
           </div>
        </div>

        {/* Center (Play/Pause indicator mainly) */}
        <div className="flex-1 flex items-center justify-center pointer-events-none">
           {!controls.playing && (
             <div className="w-24 h-24 bg-black/60 backdrop-blur-sm rounded-full flex items-center justify-center border-2 border-white/10 animate-in">
                <svg className="w-10 h-10 text-white" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
             </div>
           )}
        </div>

        {/* Bottom Controls */}
        <div className="space-y-4 pb-2 md:pb-6" onClick={e => e.stopPropagation()}>
           
           {/* Progress Bar */}
           <div className="flex flex-col gap-2 group">
              <div className="relative w-full h-1.5 bg-white/20 rounded-full cursor-pointer hover:h-2.5 transition-all">
                 <div className="absolute top-0 left-0 h-full bg-gold shadow-[0_0_15px_gold] rounded-full" style={{ width: `${controls.progress}%` }}></div>
                 <input 
                    type="range" min="0" max="100" step="0.1" 
                    value={controls.progress} 
                    className="absolute inset-0 opacity-0 w-full h-full cursor-pointer"
                    onChange={(e) => {
                      const val = parseFloat(e.target.value);
                      if (videoRef.current && isFinite(videoRef.current.duration)) {
                        videoRef.current.currentTime = (val / 100) * videoRef.current.duration;
                      }
                    }}
                 />
              </div>
              <div className="flex justify-between text-[11px] font-black font-mono text-white/70">
                 <span>{controls.currentTime}</span>
                 <span>{controls.totalTime}</span>
              </div>
           </div>

           {/* Control Buttons Row */}
           <div className="flex justify-between items-center">
              
              {/* Left Group */}
              <div className="flex items-center gap-4 md:gap-6">
                 <button onClick={togglePlay} className="focusable p-2 text-white hover:text-gold transition-colors">
                    {controls.playing ? 
                      <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M6 19h4V5H6v14zm8-14v14h4V5h-4z"/></svg> : 
                      <svg className="w-8 h-8" fill="currentColor" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
                    }
                 </button>

                 <div className="w-px h-8 bg-white/10 mx-2"></div>

                 {/* Audio Button */}
                 <button onClick={() => setMenu({open:true, type:'audio'})} className="focusable flex flex-col items-center gap-1 group text-white hover:text-gold relative">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M19 11a7 7 0 01-7 7m0 0a7 7 0 01-7-7m7 7v4m0 0H8m4 0h4m-4-8a3 3 0 01-3-3V5a3 3 0 116 0v6a3 3 0 01-3 3z"/></svg>
                    <span className="text-[9px] font-bold opacity-60 group-hover:opacity-100">AUDIO</span>
                 </button>

                 {/* Quality Button (Moved Here) */}
                 <button onClick={() => setMenu({open:true, type:'quality'})} className="focusable flex flex-col items-center gap-1 group text-white hover:text-gold">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"/><path strokeLinecap="round" strokeLinejoin="round" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"/></svg>
                    <span className="text-[9px] font-bold opacity-60 group-hover:opacity-100">QUALITY</span>
                 </button>
              </div>

              {/* Right Group */}
              <div className="flex gap-6 items-center">
                 <button onClick={() => setAspectRatio(aspectRatio === 'contain' ? 'cover' : 'contain')} className="focusable flex flex-col items-center gap-1 group text-white hover:text-gold">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24"><path d="M4 8V4h4M16 4h4v4M4 16v4h4M16 20h4v-4"/></svg>
                    <span className="text-[9px] font-bold opacity-60 group-hover:opacity-100">{aspectRatio}</span>
                 </button>
                 
                 {/* Fullscreen Button */}
                 <button onClick={toggleFullScreen} className="focusable p-2 text-white hover:text-gold">
                    {isFullScreen ? 
                       <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7" /></svg>
                       : 
                       <svg className="w-8 h-8" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 8V4h4M16 4h4v4M4 16v4h4M16 20h4v-4" /></svg>
                    }
                 </button>
              </div>
           </div>
        </div>
      </div>

      {/* Menus Overlay */}
      {menu.open && (
        <div className="absolute inset-0 bg-black/90 backdrop-blur-md z-[100] flex items-center justify-center p-6 animate-in" onClick={() => setMenu({ ...menu, open: false })}>
          <div className="w-full max-w-sm bg-[#111] rounded-[2rem] border border-white/10 p-6 space-y-4 shadow-2xl" onClick={e => e.stopPropagation()}>
            <div className="flex justify-between items-center border-b border-white/5 pb-4">
               <h3 className="font-black text-gold uppercase tracking-widest text-lg">
                 {menu.type === 'audio' ? 'Audio Source' : menu.type === 'quality' ? 'Quality Select' : 'Settings'}
               </h3>
               <button onClick={() => setMenu({ ...menu, open: false })} className="p-2 bg-white/5 rounded-full hover:bg-white/10"><svg className="w-5 h-5 text-white" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12"/></svg></button>
            </div>
            
            <div className="space-y-2 max-h-[50vh] overflow-y-auto pr-2 custom-scroll">
               
               {/* QUALITY MENU */}
               {menu.type === 'quality' && (
                 <>
                   {isYoutube ? (
                     <div className="p-4 text-center text-white/50">YouTube Auto Quality</div>
                   ) : (
                     <>
                        <button 
                          onClick={() => changeQuality('auto')}
                          className={`w-full p-4 rounded-xl flex justify-between items-center font-bold transition-all ${tracks.currentQuality === 'auto' ? 'bg-gold text-black' : 'bg-white/5 text-white hover:bg-white/10'}`}
                        >
                           <span>Auto (Adaptive)</span>
                           {tracks.currentQuality === 'auto' && <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>}
                        </button>
                        {tracks.quality.map((q: any) => (
                           <button 
                             key={q.id}
                             onClick={() => changeQuality(q.height)}
                             className={`w-full p-4 rounded-xl flex justify-between items-center font-bold transition-all ${tracks.currentQuality === q.height.toString() ? 'bg-gold text-black' : 'bg-white/5 text-white hover:bg-white/10'}`}
                           >
                              <span>{q.height}p <span className="text-xs opacity-60">({Math.round(q.bandwidth / 1000)} kbps)</span></span>
                              {tracks.currentQuality === q.height.toString() && <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>}
                           </button>
                        ))}
                     </>
                   )}
                 </>
               )}

               {/* AUDIO MENU */}
               {menu.type === 'audio' && (
                 <>
                   {tracks.audio.length === 0 ? (
                     <div className="p-4 text-center text-white/50">No Alternate Audio</div>
                   ) : (
                     tracks.audio.map((lang: string, idx: number) => (
                        <button 
                          key={idx}
                          onClick={() => changeAudio(lang)}
                          className={`w-full p-4 rounded-xl flex justify-between items-center font-bold transition-all ${tracks.currentAudio === lang ? 'bg-gold text-black' : 'bg-white/5 text-white hover:bg-white/10'}`}
                        >
                           <span className="uppercase">{lang}</span>
                           {tracks.currentAudio === lang && <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20"><path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd"/></svg>}
                        </button>
                     ))
                   )}
                 </>
               )}
            </div>
          </div>
        </div>
      )}

      <style>{`
        .custom-scroll::-webkit-scrollbar { width: 4px; }
        .custom-scroll::-webkit-scrollbar-thumb { background: #FFC107; border-radius: 10px; }
        .animate-in { animation: fadeInScale 0.2s ease-out forwards; }
        @keyframes fadeInScale { from { opacity: 0; transform: scale(0.95); } to { opacity: 1; transform: scale(1); } }
      `}</style>
    </div>
  );
};

const PlayerWrapper = () => {
  const [stream, setStream] = useState<any>(null);
  useEffect(() => {
    const handleOpen = (e: any) => setStream(e.detail);
    window.addEventListener('open-player', handleOpen);
    return () => window.removeEventListener('open-player', handleOpen);
  }, []);
  if (!stream) return null;
  return <ProPlayer stream={stream} onClose={() => setStream(null)} />;
};

const root = ReactDOM.createRoot(document.getElementById('react-player-root')!);
root.render(<PlayerWrapper />);

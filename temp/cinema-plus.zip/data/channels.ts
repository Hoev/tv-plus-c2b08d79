
// File removed: This file is no longer needed as all media is fetched from TMDB.
export const EMPTY = [];
